﻿namespace WindowsFormsApp1
{
    partial class orderPizzaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sizeListBox = new System.Windows.Forms.ListBox();
            this.quantityNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.PizzabasegroupBox = new System.Windows.Forms.GroupBox();
            this.SausageRadioButton = new System.Windows.Forms.RadioButton();
            this.PepRadioButton = new System.Windows.Forms.RadioButton();
            this.CheeseRadioButton1 = new System.Windows.Forms.RadioButton();
            this.xtraToppingsGroupBox1 = new System.Windows.Forms.GroupBox();
            this.onionsCheckBox = new System.Windows.Forms.CheckBox();
            this.greenPeppersCheckBox5 = new System.Windows.Forms.CheckBox();
            this.bananapepperCheckBox = new System.Windows.Forms.CheckBox();
            this.OliveCheckBox = new System.Windows.Forms.CheckBox();
            this.hamCheckBox = new System.Windows.Forms.CheckBox();
            this.baconCheckBox = new System.Windows.Forms.CheckBox();
            this.quantityLabel = new System.Windows.Forms.Label();
            this.sizeLabel = new System.Windows.Forms.Label();
            this.orderButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.customizeLabel = new System.Windows.Forms.Label();
            this.specInstructTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumericUpDown)).BeginInit();
            this.PizzabasegroupBox.SuspendLayout();
            this.xtraToppingsGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sizeListBox
            // 
            this.sizeListBox.FormattingEnabled = true;
            this.sizeListBox.Items.AddRange(new object[] {
            "Small 12\" ",
            "Medium 14\"",
            "Large 16\"",
            "X- Large 22\""});
            this.sizeListBox.Location = new System.Drawing.Point(79, 52);
            this.sizeListBox.Name = "sizeListBox";
            this.sizeListBox.Size = new System.Drawing.Size(267, 30);
            this.sizeListBox.TabIndex = 0;
            this.sizeListBox.Visible = false;
            this.sizeListBox.SelectedIndexChanged += new System.EventHandler(this.sizeListBox_SelectedIndexChanged);
            // 
            // quantityNumericUpDown
            // 
            this.quantityNumericUpDown.Location = new System.Drawing.Point(79, 26);
            this.quantityNumericUpDown.Name = "quantityNumericUpDown";
            this.quantityNumericUpDown.Size = new System.Drawing.Size(120, 20);
            this.quantityNumericUpDown.TabIndex = 1;
            this.quantityNumericUpDown.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // PizzabasegroupBox
            // 
            this.PizzabasegroupBox.Controls.Add(this.SausageRadioButton);
            this.PizzabasegroupBox.Controls.Add(this.PepRadioButton);
            this.PizzabasegroupBox.Controls.Add(this.CheeseRadioButton1);
            this.PizzabasegroupBox.Location = new System.Drawing.Point(12, 88);
            this.PizzabasegroupBox.Name = "PizzabasegroupBox";
            this.PizzabasegroupBox.Size = new System.Drawing.Size(127, 100);
            this.PizzabasegroupBox.TabIndex = 2;
            this.PizzabasegroupBox.TabStop = false;
            this.PizzabasegroupBox.Text = "Select Pizza base";
            this.PizzabasegroupBox.Visible = false;
            // 
            // SausageRadioButton
            // 
            this.SausageRadioButton.AutoSize = true;
            this.SausageRadioButton.Location = new System.Drawing.Point(3, 62);
            this.SausageRadioButton.Name = "SausageRadioButton";
            this.SausageRadioButton.Size = new System.Drawing.Size(67, 17);
            this.SausageRadioButton.TabIndex = 4;
            this.SausageRadioButton.Text = "Sausage";
            this.SausageRadioButton.UseVisualStyleBackColor = true;
            this.SausageRadioButton.CheckedChanged += new System.EventHandler(this.SausageRadioButton_CheckedChanged);
            // 
            // PepRadioButton
            // 
            this.PepRadioButton.AutoSize = true;
            this.PepRadioButton.Location = new System.Drawing.Point(3, 39);
            this.PepRadioButton.Name = "PepRadioButton";
            this.PepRadioButton.Size = new System.Drawing.Size(73, 17);
            this.PepRadioButton.TabIndex = 3;
            this.PepRadioButton.Text = "Pepperoni";
            this.PepRadioButton.UseVisualStyleBackColor = true;
            this.PepRadioButton.CheckedChanged += new System.EventHandler(this.PepRadioButton_CheckedChanged);
            // 
            // CheeseRadioButton1
            // 
            this.CheeseRadioButton1.AutoSize = true;
            this.CheeseRadioButton1.Location = new System.Drawing.Point(3, 16);
            this.CheeseRadioButton1.Name = "CheeseRadioButton1";
            this.CheeseRadioButton1.Size = new System.Drawing.Size(61, 17);
            this.CheeseRadioButton1.TabIndex = 0;
            this.CheeseRadioButton1.Text = "Cheese";
            this.CheeseRadioButton1.UseVisualStyleBackColor = true;
            this.CheeseRadioButton1.CheckedChanged += new System.EventHandler(this.CheeseRadioButton1_CheckedChanged);
            // 
            // xtraToppingsGroupBox1
            // 
            this.xtraToppingsGroupBox1.Controls.Add(this.onionsCheckBox);
            this.xtraToppingsGroupBox1.Controls.Add(this.greenPeppersCheckBox5);
            this.xtraToppingsGroupBox1.Controls.Add(this.bananapepperCheckBox);
            this.xtraToppingsGroupBox1.Controls.Add(this.OliveCheckBox);
            this.xtraToppingsGroupBox1.Controls.Add(this.hamCheckBox);
            this.xtraToppingsGroupBox1.Controls.Add(this.baconCheckBox);
            this.xtraToppingsGroupBox1.Location = new System.Drawing.Point(161, 88);
            this.xtraToppingsGroupBox1.Name = "xtraToppingsGroupBox1";
            this.xtraToppingsGroupBox1.Size = new System.Drawing.Size(312, 100);
            this.xtraToppingsGroupBox1.TabIndex = 5;
            this.xtraToppingsGroupBox1.TabStop = false;
            this.xtraToppingsGroupBox1.Text = "Extra Toppings";
            this.xtraToppingsGroupBox1.Visible = false;
            // 
            // onionsCheckBox
            // 
            this.onionsCheckBox.AutoSize = true;
            this.onionsCheckBox.Location = new System.Drawing.Point(153, 63);
            this.onionsCheckBox.Name = "onionsCheckBox";
            this.onionsCheckBox.Size = new System.Drawing.Size(59, 17);
            this.onionsCheckBox.TabIndex = 5;
            this.onionsCheckBox.Text = "Onions";
            this.onionsCheckBox.UseVisualStyleBackColor = true;
            this.onionsCheckBox.CheckedChanged += new System.EventHandler(this.onionsCheckBox_CheckedChanged);
            // 
            // greenPeppersCheckBox5
            // 
            this.greenPeppersCheckBox5.AutoSize = true;
            this.greenPeppersCheckBox5.Location = new System.Drawing.Point(153, 40);
            this.greenPeppersCheckBox5.Name = "greenPeppersCheckBox5";
            this.greenPeppersCheckBox5.Size = new System.Drawing.Size(97, 17);
            this.greenPeppersCheckBox5.TabIndex = 4;
            this.greenPeppersCheckBox5.Text = "Green Peppers";
            this.greenPeppersCheckBox5.UseVisualStyleBackColor = true;
            this.greenPeppersCheckBox5.CheckedChanged += new System.EventHandler(this.greenPeppersCheckBox5_CheckedChanged);
            // 
            // bananapepperCheckBox
            // 
            this.bananapepperCheckBox.AutoSize = true;
            this.bananapepperCheckBox.Location = new System.Drawing.Point(153, 16);
            this.bananapepperCheckBox.Name = "bananapepperCheckBox";
            this.bananapepperCheckBox.Size = new System.Drawing.Size(105, 17);
            this.bananapepperCheckBox.TabIndex = 3;
            this.bananapepperCheckBox.Text = "Banana Peppers";
            this.bananapepperCheckBox.UseVisualStyleBackColor = true;
            this.bananapepperCheckBox.CheckedChanged += new System.EventHandler(this.bananapepperCheckBox_CheckedChanged);
            // 
            // OliveCheckBox
            // 
            this.OliveCheckBox.AutoSize = true;
            this.OliveCheckBox.Location = new System.Drawing.Point(0, 63);
            this.OliveCheckBox.Name = "OliveCheckBox";
            this.OliveCheckBox.Size = new System.Drawing.Size(55, 17);
            this.OliveCheckBox.TabIndex = 2;
            this.OliveCheckBox.Text = "Olives";
            this.OliveCheckBox.UseVisualStyleBackColor = true;
            this.OliveCheckBox.CheckedChanged += new System.EventHandler(this.OliveCheckBox_CheckedChanged);
            // 
            // hamCheckBox
            // 
            this.hamCheckBox.AutoSize = true;
            this.hamCheckBox.Location = new System.Drawing.Point(0, 40);
            this.hamCheckBox.Name = "hamCheckBox";
            this.hamCheckBox.Size = new System.Drawing.Size(48, 17);
            this.hamCheckBox.TabIndex = 1;
            this.hamCheckBox.Text = "Ham";
            this.hamCheckBox.UseVisualStyleBackColor = true;
            this.hamCheckBox.CheckedChanged += new System.EventHandler(this.hamCheckBox_CheckedChanged);
            // 
            // baconCheckBox
            // 
            this.baconCheckBox.AutoSize = true;
            this.baconCheckBox.Location = new System.Drawing.Point(0, 16);
            this.baconCheckBox.Name = "baconCheckBox";
            this.baconCheckBox.Size = new System.Drawing.Size(57, 17);
            this.baconCheckBox.TabIndex = 0;
            this.baconCheckBox.Text = "Bacon";
            this.baconCheckBox.UseVisualStyleBackColor = true;
            this.baconCheckBox.CheckedChanged += new System.EventHandler(this.baconCheckBox_CheckedChanged);
            // 
            // quantityLabel
            // 
            this.quantityLabel.AutoSize = true;
            this.quantityLabel.Location = new System.Drawing.Point(0, 33);
            this.quantityLabel.Name = "quantityLabel";
            this.quantityLabel.Size = new System.Drawing.Size(46, 13);
            this.quantityLabel.TabIndex = 6;
            this.quantityLabel.Text = "Quantity";
            // 
            // sizeLabel
            // 
            this.sizeLabel.AutoSize = true;
            this.sizeLabel.Location = new System.Drawing.Point(0, 69);
            this.sizeLabel.Name = "sizeLabel";
            this.sizeLabel.Size = new System.Drawing.Size(67, 13);
            this.sizeLabel.TabIndex = 7;
            this.sizeLabel.Text = "Select a size";
            this.sizeLabel.Visible = false;
            // 
            // orderButton
            // 
            this.orderButton.Location = new System.Drawing.Point(64, 267);
            this.orderButton.Name = "orderButton";
            this.orderButton.Size = new System.Drawing.Size(75, 23);
            this.orderButton.TabIndex = 8;
            this.orderButton.Text = "Place Order";
            this.orderButton.UseVisualStyleBackColor = true;
            this.orderButton.Click += new System.EventHandler(this.orderButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(172, 267);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear Form";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(314, 267);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // customizeLabel
            // 
            this.customizeLabel.AutoSize = true;
            this.customizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customizeLabel.Location = new System.Drawing.Point(158, 9);
            this.customizeLabel.Name = "customizeLabel";
            this.customizeLabel.Size = new System.Drawing.Size(156, 16);
            this.customizeLabel.TabIndex = 7;
            this.customizeLabel.Text = "Customize Your Pizza";
            this.customizeLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // specInstructTextBox
            // 
            this.specInstructTextBox.Location = new System.Drawing.Point(3, 206);
            this.specInstructTextBox.Multiline = true;
            this.specInstructTextBox.Name = "specInstructTextBox";
            this.specInstructTextBox.Size = new System.Drawing.Size(244, 55);
            this.specInstructTextBox.TabIndex = 11;
            this.specInstructTextBox.Text = "Special Instructions:";
            // 
            // orderPizzaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 302);
            this.Controls.Add(this.specInstructTextBox);
            this.Controls.Add(this.customizeLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.orderButton);
            this.Controls.Add(this.sizeLabel);
            this.Controls.Add(this.quantityLabel);
            this.Controls.Add(this.xtraToppingsGroupBox1);
            this.Controls.Add(this.PizzabasegroupBox);
            this.Controls.Add(this.quantityNumericUpDown);
            this.Controls.Add(this.sizeListBox);
            this.Name = "orderPizzaForm";
            this.Text = "Place Your Order";
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumericUpDown)).EndInit();
            this.PizzabasegroupBox.ResumeLayout(false);
            this.PizzabasegroupBox.PerformLayout();
            this.xtraToppingsGroupBox1.ResumeLayout(false);
            this.xtraToppingsGroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox sizeListBox;
        private System.Windows.Forms.NumericUpDown quantityNumericUpDown;
        private System.Windows.Forms.GroupBox PizzabasegroupBox;
        private System.Windows.Forms.RadioButton SausageRadioButton;
        private System.Windows.Forms.RadioButton PepRadioButton;
        private System.Windows.Forms.RadioButton CheeseRadioButton1;
        private System.Windows.Forms.GroupBox xtraToppingsGroupBox1;
        private System.Windows.Forms.CheckBox onionsCheckBox;
        private System.Windows.Forms.CheckBox greenPeppersCheckBox5;
        private System.Windows.Forms.CheckBox bananapepperCheckBox;
        private System.Windows.Forms.CheckBox OliveCheckBox;
        private System.Windows.Forms.CheckBox hamCheckBox;
        private System.Windows.Forms.CheckBox baconCheckBox;
        private System.Windows.Forms.Label quantityLabel;
        private System.Windows.Forms.Label sizeLabel;
        private System.Windows.Forms.Button orderButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label customizeLabel;
        private System.Windows.Forms.TextBox specInstructTextBox;
    }
}

