﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class orderPizzaForm : Form
    {
        public orderPizzaForm()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e) // user selects number of pizzas
        {
            //show size options
            sizeLabel.Visible = true;
            sizeListBox.Visible = true;
            //must order at least 1 pizza to move forward
            if (quantityNumericUpDown.Value == 0)
            {
                MessageBox.Show("Don't tell me you don't want ANY pizza, you gotta at least order 1");
            }
        }

        private void sizeListBox_SelectedIndexChanged(object sender, EventArgs e) //user selects the size of the pizza(s)
        {
            //must select size to move forward          
            if (sizeListBox.SelectedIndex != -1)
            {
                PizzabasegroupBox.Visible = true;

            }
            else
            {
                MessageBox.Show("Please choose a size");
            }
        }

        string pizzaBase;
         private void CheeseRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (CheeseRadioButton1.Checked)
            {
                xtraToppingsGroupBox1.Visible = true;
                pizzaBase = "Cheese";
            }

        }
           
        private void PepRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            xtraToppingsGroupBox1.Visible = true;
            if (PepRadioButton.Checked)
            {
                pizzaBase = "Pepperoni";
            }
        }

        private void SausageRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            xtraToppingsGroupBox1.Visible = true;
            if (SausageRadioButton.Checked)
            {
                pizzaBase = "Sausage";
            }
        }
        //Add extra topping to pizza. Will show up in special instructions
        private void baconCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            specInstructTextBox.Visible = true;
            if (baconCheckBox.Checked)
            {
                specInstructTextBox.Text += " " +
                    "add bacon";
            }
            else if (baconCheckBox.Checked == false)
            {
                specInstructTextBox.Text.DefaultIfEmpty();
            }
        }

        private void hamCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (hamCheckBox.Checked)
            {
                specInstructTextBox.Visible = true;
                specInstructTextBox.Text += " " +
                    "add ham ";
            }
            else if (hamCheckBox.Checked == false)
            {
                specInstructTextBox.Text.DefaultIfEmpty();
            }
        }

        private void OliveCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (OliveCheckBox.Checked)
            {
                specInstructTextBox.Visible = true;
                specInstructTextBox.Text += " add Olives ";
            }
            else if (onionsCheckBox.Checked == false) 
            {
                specInstructTextBox.Text.DefaultIfEmpty(); 
            }
        }

        private void bananapepperCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (bananapepperCheckBox.Checked)
            {
                specInstructTextBox.Text += " add Banana Peppers ";
            }
            else if (bananapepperCheckBox.Checked == false)
            {
                specInstructTextBox.Text.DefaultIfEmpty();
            }
        }

        private void greenPeppersCheckBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (greenPeppersCheckBox5.Checked)
            {
                specInstructTextBox.Text += " add Green Peppers ";
            }
            else if (greenPeppersCheckBox5.Checked == false)
            {
                specInstructTextBox.Text.DefaultIfEmpty();
            }
        }

        private void onionsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            string onions = " add onions";
            if (onionsCheckBox.Checked)
            {
                specInstructTextBox.Text += onions;
            }
            else if (onionsCheckBox.Checked == false)
            {
                
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void orderButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your order for " + " " + quantityNumericUpDown.Value + " " + sizeListBox.SelectedItem + " " + pizzaBase +
                " with " + specInstructTextBox.Text.Substring(21) + " has been placed!! Thank you for your patronage!!");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            quantityNumericUpDown.Value = 0;
            sizeListBox.SelectedItem = 0;
            CheeseRadioButton1.Checked = true;
            pizzaBase = " ";
            baconCheckBox.Checked = false;
            hamCheckBox.Checked = false;
            OliveCheckBox.Checked = false;
            bananapepperCheckBox.Checked = false;
            greenPeppersCheckBox5.Checked = false;
            onionsCheckBox.Checked = false;
            specInstructTextBox.Text = "Special Instructions ";
        }

       
    }
}
