﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int seconds, remainingSeconds, minutes, hours, days; //holds the variables to be calculated

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            secondsTextBox.Text = " ";
            remainingSecondsResultsLabel.Text = " ";
            minutesResultsLabel.Text = " ";
            hoursResultsLabel.Text = " ";
            daysResultsLabel.Text = " ";
            secondsTextBox.Focus();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(secondsTextBox.Text, out seconds))
            {
                if(seconds < 60)
                {
                    remainingSeconds = seconds;
                    remainingSecondsResultsLabel.Text = remainingSeconds.ToString();
                }
                else if(seconds >= 60 && seconds <= 3600)
                {
                    days = seconds / 86400;
                    hours = seconds / 3600;
                    minutes = (seconds % 3600) / 60;
                    remainingSeconds = (seconds % 3600) % 60;
                    remainingSecondsResultsLabel.Text = remainingSeconds.ToString();
                    minutesResultsLabel.Text = minutes.ToString();
                    hoursResultsLabel.Text = hours.ToString();
                    daysResultsLabel.Text = days.ToString();
                } 
                else if(seconds >= 3600)
                {
                    days = seconds / 86400;
                    hours = (seconds % 86400) / 3600;
                    minutes = ((seconds % 86400) % 3600) / 60;
                    remainingSeconds = ((seconds % 86400) % 3600) % 60;
                    remainingSecondsResultsLabel.Text = remainingSeconds.ToString();
                    minutesResultsLabel.Text = minutes.ToString();
                    hoursResultsLabel.Text = hours.ToString();
                    daysResultsLabel.Text = days.ToString();
                }
            }
            else
            {
                MessageBox.Show("Please enter integer!! hint: A number without decimals");
            }
        }
    }
}
