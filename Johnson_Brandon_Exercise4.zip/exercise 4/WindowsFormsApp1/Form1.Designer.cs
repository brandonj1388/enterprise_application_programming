﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.inputPrompt = new System.Windows.Forms.Label();
            this.secondsTextBox = new System.Windows.Forms.TextBox();
            this.secondsLabel = new System.Windows.Forms.Label();
            this.DaysLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.minutesLabel = new System.Windows.Forms.Label();
            this.remainingSecondsabel = new System.Windows.Forms.Label();
            this.convertButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.daysResultsLabel = new System.Windows.Forms.Label();
            this.hoursResultsLabel = new System.Windows.Forms.Label();
            this.minutesResultsLabel = new System.Windows.Forms.Label();
            this.remainingSecondsResultsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.BackColor = System.Drawing.Color.Silver;
            this.instructionsLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.instructionsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionsLabel.Location = new System.Drawing.Point(0, 0);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(305, 69);
            this.instructionsLabel.TabIndex = 0;
            this.instructionsLabel.Text = "Enter a number in seconds and I will convert to days, hours, minutes,and the rema" +
    "ining seconds";
            // 
            // inputPrompt
            // 
            this.inputPrompt.AutoSize = true;
            this.inputPrompt.Location = new System.Drawing.Point(12, 75);
            this.inputPrompt.Name = "inputPrompt";
            this.inputPrompt.Size = new System.Drawing.Size(79, 13);
            this.inputPrompt.TabIndex = 1;
            this.inputPrompt.Text = "Enter a integer ";
            // 
            // secondsTextBox
            // 
            this.secondsTextBox.Location = new System.Drawing.Point(97, 72);
            this.secondsTextBox.Name = "secondsTextBox";
            this.secondsTextBox.Size = new System.Drawing.Size(100, 20);
            this.secondsTextBox.TabIndex = 2;
            // 
            // secondsLabel
            // 
            this.secondsLabel.AutoSize = true;
            this.secondsLabel.Location = new System.Drawing.Point(203, 79);
            this.secondsLabel.Name = "secondsLabel";
            this.secondsLabel.Size = new System.Drawing.Size(52, 13);
            this.secondsLabel.TabIndex = 3;
            this.secondsLabel.Text = "Seconds ";
            // 
            // DaysLabel
            // 
            this.DaysLabel.AutoSize = true;
            this.DaysLabel.Location = new System.Drawing.Point(203, 136);
            this.DaysLabel.Name = "DaysLabel";
            this.DaysLabel.Size = new System.Drawing.Size(31, 13);
            this.DaysLabel.TabIndex = 4;
            this.DaysLabel.Text = "Days";
            // 
            // hoursLabel
            // 
            this.hoursLabel.AutoSize = true;
            this.hoursLabel.Location = new System.Drawing.Point(203, 166);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(35, 13);
            this.hoursLabel.TabIndex = 5;
            this.hoursLabel.Text = "Hours";
            // 
            // minutesLabel
            // 
            this.minutesLabel.AutoSize = true;
            this.minutesLabel.Location = new System.Drawing.Point(203, 191);
            this.minutesLabel.Name = "minutesLabel";
            this.minutesLabel.Size = new System.Drawing.Size(44, 13);
            this.minutesLabel.TabIndex = 6;
            this.minutesLabel.Text = "Minutes";
            // 
            // remainingSecondsabel
            // 
            this.remainingSecondsabel.AutoSize = true;
            this.remainingSecondsabel.Location = new System.Drawing.Point(203, 215);
            this.remainingSecondsabel.Name = "remainingSecondsabel";
            this.remainingSecondsabel.Size = new System.Drawing.Size(102, 13);
            this.remainingSecondsabel.TabIndex = 7;
            this.remainingSecondsabel.Text = "Remaining Seconds";
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(68, 98);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(75, 23);
            this.convertButton.TabIndex = 8;
            this.convertButton.Text = "Convert";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(172, 98);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(0, 236);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // daysResultsLabel
            // 
            this.daysResultsLabel.AutoSize = true;
            this.daysResultsLabel.BackColor = System.Drawing.SystemColors.HighlightText;
            this.daysResultsLabel.Location = new System.Drawing.Point(137, 136);
            this.daysResultsLabel.Name = "daysResultsLabel";
            this.daysResultsLabel.Size = new System.Drawing.Size(10, 13);
            this.daysResultsLabel.TabIndex = 11;
            this.daysResultsLabel.Text = " ";
            // 
            // hoursResultsLabel
            // 
            this.hoursResultsLabel.AutoSize = true;
            this.hoursResultsLabel.BackColor = System.Drawing.SystemColors.HighlightText;
            this.hoursResultsLabel.Location = new System.Drawing.Point(137, 166);
            this.hoursResultsLabel.Name = "hoursResultsLabel";
            this.hoursResultsLabel.Size = new System.Drawing.Size(10, 13);
            this.hoursResultsLabel.TabIndex = 12;
            this.hoursResultsLabel.Text = " ";
            // 
            // minutesResultsLabel
            // 
            this.minutesResultsLabel.AutoSize = true;
            this.minutesResultsLabel.BackColor = System.Drawing.SystemColors.HighlightText;
            this.minutesResultsLabel.Location = new System.Drawing.Point(137, 191);
            this.minutesResultsLabel.Name = "minutesResultsLabel";
            this.minutesResultsLabel.Size = new System.Drawing.Size(10, 13);
            this.minutesResultsLabel.TabIndex = 13;
            this.minutesResultsLabel.Text = " ";
            // 
            // remainingSecondsResultsLabel
            // 
            this.remainingSecondsResultsLabel.AutoSize = true;
            this.remainingSecondsResultsLabel.BackColor = System.Drawing.SystemColors.HighlightText;
            this.remainingSecondsResultsLabel.Location = new System.Drawing.Point(137, 215);
            this.remainingSecondsResultsLabel.Name = "remainingSecondsResultsLabel";
            this.remainingSecondsResultsLabel.Size = new System.Drawing.Size(10, 13);
            this.remainingSecondsResultsLabel.TabIndex = 14;
            this.remainingSecondsResultsLabel.Text = " ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 261);
            this.Controls.Add(this.remainingSecondsResultsLabel);
            this.Controls.Add(this.minutesResultsLabel);
            this.Controls.Add(this.hoursResultsLabel);
            this.Controls.Add(this.daysResultsLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.remainingSecondsabel);
            this.Controls.Add(this.minutesLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.DaysLabel);
            this.Controls.Add(this.secondsLabel);
            this.Controls.Add(this.secondsTextBox);
            this.Controls.Add(this.inputPrompt);
            this.Controls.Add(this.instructionsLabel);
            this.Name = "Form1";
            this.Text = "Time Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label inputPrompt;
        private System.Windows.Forms.TextBox secondsTextBox;
        private System.Windows.Forms.Label secondsLabel;
        private System.Windows.Forms.Label DaysLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label minutesLabel;
        private System.Windows.Forms.Label remainingSecondsabel;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label daysResultsLabel;
        private System.Windows.Forms.Label hoursResultsLabel;
        private System.Windows.Forms.Label minutesResultsLabel;
        private System.Windows.Forms.Label remainingSecondsResultsLabel;
    }
}

