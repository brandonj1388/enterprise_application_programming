﻿namespace Exercise3
{
    partial class Exercise3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.fiveHourButton = new System.Windows.Forms.Button();
            this.fiveHourLabel = new System.Windows.Forms.Label();
            this.eightHourButton = new System.Windows.Forms.Button();
            this.eightHourLabel = new System.Windows.Forms.Label();
            this.twelveHourButton = new System.Windows.Forms.Button();
            this.twelveHourLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxLabel
            // 
            this.textBoxLabel.AutoSize = true;
            this.textBoxLabel.Location = new System.Drawing.Point(3, 3);
            this.textBoxLabel.Name = "textBoxLabel";
            this.textBoxLabel.Size = new System.Drawing.Size(129, 13);
            this.textBoxLabel.TabIndex = 0;
            this.textBoxLabel.Text = "Enter Speed of car (MPH)";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(133, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // fiveHourButton
            // 
            this.fiveHourButton.Location = new System.Drawing.Point(12, 58);
            this.fiveHourButton.Name = "fiveHourButton";
            this.fiveHourButton.Size = new System.Drawing.Size(91, 51);
            this.fiveHourButton.TabIndex = 2;
            this.fiveHourButton.Text = "Distance after 5 hours";
            this.fiveHourButton.UseVisualStyleBackColor = true;
            this.fiveHourButton.Click += new System.EventHandler(this.fiveHourButton_Click);
            // 
            // fiveHourLabel
            // 
            this.fiveHourLabel.Location = new System.Drawing.Point(12, 173);
            this.fiveHourLabel.Name = "fiveHourLabel";
            this.fiveHourLabel.Size = new System.Drawing.Size(91, 30);
            this.fiveHourLabel.TabIndex = 3;
            this.fiveHourLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fiveHourLabel.Visible = false;
            // 
            // eightHourButton
            // 
            this.eightHourButton.Location = new System.Drawing.Point(133, 58);
            this.eightHourButton.Name = "eightHourButton";
            this.eightHourButton.Size = new System.Drawing.Size(100, 51);
            this.eightHourButton.TabIndex = 4;
            this.eightHourButton.Text = "Distance after 8 hours";
            this.eightHourButton.UseVisualStyleBackColor = true;
            this.eightHourButton.Click += new System.EventHandler(this.eightHourButton_Click);
            // 
            // eightHourLabel
            // 
            this.eightHourLabel.Location = new System.Drawing.Point(133, 180);
            this.eightHourLabel.Name = "eightHourLabel";
            this.eightHourLabel.Size = new System.Drawing.Size(100, 23);
            this.eightHourLabel.TabIndex = 5;
            this.eightHourLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.eightHourLabel.Visible = false;
            // 
            // twelveHourButton
            // 
            this.twelveHourButton.Location = new System.Drawing.Point(267, 58);
            this.twelveHourButton.Name = "twelveHourButton";
            this.twelveHourButton.Size = new System.Drawing.Size(103, 51);
            this.twelveHourButton.TabIndex = 6;
            this.twelveHourButton.Text = "Distance after 12 hours";
            this.twelveHourButton.UseVisualStyleBackColor = true;
            this.twelveHourButton.Click += new System.EventHandler(this.twelveHourButton_Click);
            // 
            // twelveHourLabel
            // 
            this.twelveHourLabel.Location = new System.Drawing.Point(270, 180);
            this.twelveHourLabel.Name = "twelveHourLabel";
            this.twelveHourLabel.Size = new System.Drawing.Size(100, 23);
            this.twelveHourLabel.TabIndex = 7;
            this.twelveHourLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.twelveHourLabel.Visible = false;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(273, 206);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Exercise3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 261);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.twelveHourLabel);
            this.Controls.Add(this.twelveHourButton);
            this.Controls.Add(this.eightHourLabel);
            this.Controls.Add(this.eightHourButton);
            this.Controls.Add(this.fiveHourLabel);
            this.Controls.Add(this.fiveHourButton);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBoxLabel);
            this.Name = "Exercise3";
            this.Text = "Exercise3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label textBoxLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button fiveHourButton;
        private System.Windows.Forms.Label fiveHourLabel;
        private System.Windows.Forms.Button eightHourButton;
        private System.Windows.Forms.Label eightHourLabel;
        private System.Windows.Forms.Button twelveHourButton;
        private System.Windows.Forms.Label twelveHourLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

