﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise3
{
    public partial class Exercise3 : Form
    {
        public Exercise3()
        {
            InitializeComponent();
        }

        private void fiveHourButton_Click(object sender, EventArgs e)
        {
            try
            {
                double speed = double.Parse(textBox1.Text);
                double distance = speed * 5.0;
                fiveHourLabel.Visible = true;
                fiveHourLabel.Text = distance.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
         }
        private void eightHourButton_Click(object sender, EventArgs e)
        {
            try
            {
                double speed = double.Parse(textBox1.Text);
                double distance = speed * 8.0;
                eightHourLabel.Visible = true;
                eightHourLabel.Text = distance.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
            private void twelveHourButton_Click(object sender, EventArgs e)
            {
            try
            {
                double speed = double.Parse(textBox1.Text);
                double distance = speed * 12.0;
                twelveHourLabel.Visible = true;
                twelveHourLabel.Text = distance.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            }
                
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
